# Biblioteca Personal con KeyDB

## Descripción

Biblioteca Personal es una aplicación web desarrollada en Python utilizando Flask y KeyDB. Permite administrar una colección personal de libros mediante una interfaz gráfica sencilla e intuitiva.

Los registros se almacenan en KeyDB en formato JSON, mientras que las imágenes de portada se guardan localmente en el servidor.

## Funcionalidades

- Registrar libros.
- Visualizar la colección de libros.
- Buscar libros por título, autor o género.
- Editar la información de los libros.
- Eliminar libros.
- Asignar y cambiar imágenes de portada.
- Seleccionar el estado de lectura.
- Validar campos obligatorios.
- Evitar registros duplicados por título y autor.

## Tecnologías utilizadas

- Python
- Flask
- KeyDB
- Redis-py
- HTML5
- CSS3
- Jinja2
- JSON
- Docker
- python-dotenv

## Requisitos previos

- Python 3 instalado.
- Docker Desktop instalado y ejecutándose.
- KeyDB disponible mediante Docker.

## Instalación

### 1. Descargar o copiar el proyecto

Abrir una terminal dentro de la carpeta principal del proyecto.

### 2. Iniciar KeyDB

Ejecutar:

```bash
docker run -d --name biblioteca-keydb-server -p 6379:6379 eqalpha/keydb
```

Si el contenedor ya existe, ejecutar:

```bash
docker start biblioteca-keydb-server
```

### 3. Instalar dependencias

```bash
python -m pip install -r requirements.txt
```

### 4. Configurar variables de entorno

Crear un archivo `.env` en la carpeta principal:

```env
KEYDB_HOST=localhost
KEYDB_PORT=6379
KEYDB_PASSWORD=
KEYDB_DB=0
SECRET_KEY=colocar_una_clave_segura
```

### 5. Ejecutar la aplicación

```bash
python app.py
```

Abrir el navegador en:

http://127.0.0.1:5000

## Almacenamiento de datos

Los libros se almacenan en KeyDB utilizando claves con el formato:

`libro:<id>`

Cada registro contiene información serializada en formato JSON.

El identificador de los libros se genera mediante un contador almacenado en:

`libros:ultimo_id`

Las imágenes de portada se guardan en:

`static/uploads/`

## Estructura del proyecto

```text
biblioteca-keydb/
│
├── app.py
├── config.py
├── database.py
├── crud.py
├── requirements.txt
├── README.md
├── .env
│
├── static/
│   ├── style.css
│   └── uploads/
│
└── templates/
    ├── base.html
    ├── index.html
    ├── agregar.html
    └── editar.html
```

## Autor

Proyecto académico desarrollado para la asignatura de Programación de Computadoras IV.